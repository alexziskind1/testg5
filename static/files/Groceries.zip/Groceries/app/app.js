var applicationModule = require("tns-core-modules/application");
applicationModule.run({ moduleName: "app-root" });
